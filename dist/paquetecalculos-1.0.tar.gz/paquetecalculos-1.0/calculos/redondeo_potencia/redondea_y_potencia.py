def potencia(base, exponente):
	print("El resultado del exponente es:", base**exponente)

def redondear(numero):
	print("El resultado del redondeo es:", round(numero))