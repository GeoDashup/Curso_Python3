from setuptools import setup


setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Ismael",
	author_email="jaunismael06@gmail.com",
	packages=["calculos", "calculos.redondeo_potencia"]



	)